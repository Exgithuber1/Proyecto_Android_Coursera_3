package com.nakamiinvenciones.miformularioandroid;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    String fnombre, ffecha, ftelefono, fdescripcion, femail, sffecha;
    CalendarView calendario;
    EditText nombre;
    EditText telefono;
    EditText campoemail;
    EditText descripcion;
    TextView next;
    boolean alpresionar;

    int dia = 1;
    int mes = 1;
    int ano = 1970;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre = (EditText) findViewById(R.id.etNombre);
        calendario = (CalendarView) findViewById(R.id.cvCalendario);
        telefono = (EditText) findViewById(R.id.etTelefono);
        campoemail = (EditText) findViewById(R.id.etEmail);
        descripcion = (EditText) findViewById(R.id.etDescripcion);
        next = (TextView) findViewById(R.id.btSiguiente);

        calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener(){
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendar, int cAno, int cMes, int cDia) {
                  dia = cDia;
                  mes = cMes + 1;
                  ano = cAno;
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fnombre = nombre.getText().toString();
                femail = campoemail.getText().toString();
                fdescripcion = descripcion.getText().toString();
                ftelefono = telefono.getText().toString();
                ffecha = dia + "/" + mes + "/" + ano;
                boolean estaCompleto = false;

                if (TextUtils.isEmpty(fnombre) || TextUtils.isEmpty(femail) || TextUtils.isEmpty(fdescripcion) || TextUtils.isEmpty(ftelefono)){
                    if (TextUtils.isEmpty(fnombre)) {
                        nombre.setError("campo requerido");
                    }
                    if (TextUtils.isEmpty(femail)) {
                        campoemail.setError("campo requerido");
                    }
                    if (TextUtils.isEmpty(fdescripcion)) {
                        descripcion.setError("campo requerido");
                    }
                    if (TextUtils.isEmpty(ftelefono)) {
                        telefono.setError("campo requerido");
                    }
                } else {
                    estaCompleto = true;
                }

                if (estaCompleto) {
                    Intent commit = new Intent(MainActivity.this, DetalleFormulario.class);
                    commit.putExtra(getResources().getString(R.string.entradanombre),fnombre);
                    commit.putExtra(getResources().getString(R.string.entradaemail),femail);
                    commit.putExtra(getResources().getString(R.string.entradatelefono),ftelefono);
                    commit.putExtra(getResources().getString(R.string.titulodescripcion),fdescripcion);
                    commit.putExtra(getResources().getString(R.string.fecha),ffecha);
                    startActivity(commit);
                }
            }
        });
    }

    public void onBackPressed(){

    }

}