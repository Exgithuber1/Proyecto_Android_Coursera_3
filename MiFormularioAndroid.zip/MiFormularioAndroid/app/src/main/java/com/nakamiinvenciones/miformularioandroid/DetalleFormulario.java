package com.nakamiinvenciones.miformularioandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class DetalleFormulario extends AppCompatActivity {
    TextView nombreF;
    TextView fechaF;
    TextView telefonoF;
    TextView emailF;
    TextView descripcionF;
    TextView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_formulario);

        Bundle param = getIntent().getExtras();
        String nombre = param.getString("Nombre Completo");
        String correo = param.getString("Correo Electronico");
        String telefono = param.getString("Telefono");
        String descripcion = param.getString("Descripcion");
        String miFecha = param.getString("");

        nombreF = (TextView) findViewById(R.id.tvNombre);
        emailF = (TextView) findViewById(R.id.tvSubtituloEmail);
        fechaF = (TextView) findViewById(R.id.tvSubtituloFecha);
        descripcionF = (TextView) findViewById(R.id.tvSubtituloDescripcion);
        telefonoF = (TextView) findViewById(R.id.tvSubtituloTelefono);
        back = (TextView) findViewById(R.id.btnEditarDatos);

        nombreF.setText("Nombre: " + nombre);
        emailF.setText("Correo Electronico: " + correo);
        fechaF.setText("Fecha: " + miFecha);
        telefonoF.setText("Telefono: " + telefono);
        descripcionF.setText("Descripcion: \n" + descripcion);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}